package com.nu.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.nu.model.Student;
import com.nu.service.StudentService;

@Controller
public class StudentController {
	@Autowired
	private StudentService studentService;
	
	@RequestMapping("/index")
	public String setupForm(Map<String, Object> map){
		Student student = new Student();
		map.put("student", student);
		map.put("studentList", studentService.getAllStudent());
		return "student";
	}
	
	@RequestMapping(value="/student.do",method=RequestMethod.POST)
	public String doActions(@ModelAttribute Student student, BindingResult result, @RequestParam String action, Map<String, Object> map){
		Student student1 = new Student();
		switch(action.toLowerCase()){
		case "add":
			studentService.add(student);
			student1=student;
			break;
		case "update":
			studentService.update(student);
			student1=student;
			break;
		case "delete":
			studentService.delete(student.getStudentID());
			student1=new Student();
			break;
		case "search":
			Student searchedStudent = studentService.getStudent(student.getStudentID());
			student1=searchedStudent!=null ? searchedStudent:new Student();
			break;
		}
		map.put("student", student1);
		map.put("studentList", studentService.getAllStudent());
		return "student";
	}
}
