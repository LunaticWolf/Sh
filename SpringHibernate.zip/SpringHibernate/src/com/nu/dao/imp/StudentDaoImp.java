package com.nu.dao.imp;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nu.dao.StudentDao;
import com.nu.model.Student;

@Repository
public class StudentDaoImp implements StudentDao{

	@Autowired
	private SessionFactory session;
	@Override
	public void add(Student student) {
		session.getCurrentSession().save(student);
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(Student student) {
		session.getCurrentSession().update(student);
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(int studentId) {
		session.getCurrentSession().delete(getStudent(studentId));
		// TODO Auto-generated method stub
		
	}

	@Override
	public Student getStudent(int studentId) {
		// TODO Auto-generated method stub
		return (Student)session.getCurrentSession().get(Student.class, studentId);
	}

	@Override
	public List getAllStudent() {
		// TODO Auto-generated method stub
		return session.getCurrentSession().createQuery("from Student").list();
	}

}
