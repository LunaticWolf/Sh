package com.nu.service.imp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nu.dao.StudentDao;
import com.nu.model.Student;
import com.nu.service.StudentService;


@Service
public class StudentServiceImp implements StudentService{
	
	@Autowired
	private StudentDao studentdao;

	@Transactional
	public void add(Student student) {
		// TODO Auto-generated method stub
		studentdao.add(student);
		
	}

	@Transactional
	public void update(Student student) {
		// TODO Auto-generated method stub
		studentdao.update(student);
		
	}

	@Transactional
	public void delete(int studentId) {
		// TODO Auto-generated method stub
		studentdao.delete(studentId);
		
	}

	@Transactional
	public Student getStudent(int studentId) {
		// TODO Auto-generated method stub
		return studentdao.getStudent(studentId);
	}

	@Transactional
	public List getAllStudent() {
		// TODO Auto-generated method stub
		return studentdao.getAllStudent();
	}

}
