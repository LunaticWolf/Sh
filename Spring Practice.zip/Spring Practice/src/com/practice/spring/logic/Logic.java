package com.practice.spring.logic;

public class Logic {

	public String logics(String num)
	{
		if(num.equals("0"))
			throw new NullPointerException();
		else{
		System.out.println("here is the main logic");
		return num;
	}
}
}