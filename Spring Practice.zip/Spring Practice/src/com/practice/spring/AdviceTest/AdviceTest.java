package com.practice.spring.AdviceTest;

import java.lang.reflect.Method;
import java.util.Arrays;

import org.aopalliance.intercept.MethodInvocation;
import org.springframework.aop.AfterReturningAdvice;
import org.springframework.aop.MethodBeforeAdvice;
import org.springframework.aop.ThrowsAdvice;
import org.springframework.cglib.proxy.MethodInterceptor;
import org.springframework.cglib.proxy.MethodProxy;

/*public class AdviceTest implements MethodBeforeAdvice {

	@Override
	public void before(Method x, Object[] arg1, Object arg2)
			throws Throwable {
		
		System.out.println("before main logic implementation");
		
	}*/

/*public class AdviceTest implements AfterReturningAdvice{

	@Override
	public void afterReturning(Object x, Method arg1, Object[] arg2,
			Object arg3) throws Throwable {
		System.out.println("Logic after returning from main logic");
		
	}*/


/*public class AdviceTest implements ThrowsAdvice{
	
	public void afterThrowing(Method m,Object args[],
			Object target,Exception e) {
		System.out.println("If this advice is called then there is chances of "
				+ "some exception has occured (you may have passed 0 in the logic call)");
	} */



public class AdviceTest implements org.aopalliance.intercept.MethodInterceptor{

	@Override
	public Object invoke(MethodInvocation x) throws Throwable {
		
		System.out.println("before interception");
		
		System.out.println("Method name"+ x.getMethod().getName());
		System.out.println("Method arguments" + Arrays.toString(x.getArguments()));
		
		Object[] y=x.getArguments();
		System.out.println(y.toString());
		
		Object obj=x.proceed();
		System.out.println("after interception");
		System.out.println("Method arguments changed" + Arrays.toString(x.getArguments()));
		
		return obj;
	}

	} 


